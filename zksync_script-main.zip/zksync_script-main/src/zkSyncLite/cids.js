export const cids = [
  { "CID": "bafybeial3e2go2w2pv5ztpk6kehqdcsoiu3v7772w2zz5stmqkxn6hkiiq", "index": 0 },
  { "CID": "bafybeibjsi4ub6obakinxfa6w5fu3szdlnuiys5vsbu2dv4hu74b7fe3lq", "index": 1 },
  { "CID": "bafybeibytjq4ej4d6fkmbve4n3bifqkwjdw6rkvep26mcqcacqvbus5srm", "index": 2 },
  { "CID": "bafkreie2glre2jrvoucri5ttr3qjnhmttoeyyinm46d4aae3kwdnoqf2t4", "index": 3 },
  { "CID": "bafkreianyhbcl5ccwtaztjblvzsu5htlxlhjctudddmqbqwmytdu6hqcv4", "index": 4 },
  { "CID": "bafybeifivoufw6qityx6qymnretfcu6b6wnsgygdaockpjthhmpc2ob3oa", "index": 5 },
  { "CID": "bafkreihba5r22exzoac27hikvg35ozvsaik4qru3acr3ia5e4ueuxy6mo4", "index": 6 },
  { "CID": "bafybeifscpz3gpm55li6gt3s5asly6y4cjypkij24j5xq4qqq7k6zbyawy", "index": 7 },
  { "CID": "bafybeib73n57cef3fvpgs4z6ogbhxuc7gkvse77yo7pc4u7zahu5ky53qy", "index": 8 },
  { "CID": "bafkreifyhvuj4c3dg2vr6jf3m2buine23zjobsrf6amxt5dwvxfhrqya6i", "index": 9 },
  { "CID": "bafkreieb5ktoswxhg2kdrnsldjcg3k6k5k7wvf7akwviawtl7tdddaekme", "index": 10 },
  { "CID": "bafybeievnh5afomymyxx5wwqmj7icxrb2fyngs5bcvundbcuyitbbdnima", "index": 11 },
  { "CID": "bafybeihuawfoiohxob6t6lgnhferadggqhkrt4q6x5sscv4ttxlo7whl6m", "index": 12 },
]
export default cids;