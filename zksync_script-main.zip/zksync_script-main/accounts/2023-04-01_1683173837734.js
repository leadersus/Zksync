[
    //示例（eg）
    {

        "index": 1, //第1个钱包账户 （wallet index）
        "address": "0x812C741F00b85176DD01beBD78FB0ba22E6EE9C7", //钱包地址（wallet address）
        "privateKey": "0xfe94e670d58f3afa4b81f56f0350684424ba6a8753baf35768df36a06bae8ef3"//钱包私钥（wallet private key）
    },
    {
        "index": 2,  //第2个钱包账户 （wallet index）
        "address": "0xCbbAD067433926D289d652F4A939b5141B2B67B4", //钱包地址（wallet address）
        "privateKey": "0x3b772b9a97241e9aaa25283dc577be9f9217c74b2715afdbcd9de80645928e85"//钱包私钥（wallet private key）
    },
]